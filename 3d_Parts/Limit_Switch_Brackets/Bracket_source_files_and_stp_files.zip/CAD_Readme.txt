Brackets were created and exported from Autodest Inventor Professional 2017 
Build: 196, Release: 2017SP1 - Date: Wed 07-13-2016